class InputError(Exception):
    code = 400
    message = 'InputError'
